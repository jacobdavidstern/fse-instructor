# Project Idea and User Discovery Plan

**Time Box: 2-3 days, 2-3 hours total**

If you need longer than this to find an idea and users, choose one of the suggested projects (Task Management or Content Sharing) instead.

## Finding a Good Project Idea

The best projects solve real problems for real people. Start by identifying pain points in your daily life or in the lives of people around you.

### Where Good Ideas Come From

**Look for friction in daily tasks:**
- What do you do repeatedly that feels tedious?
- What task requires too many steps or tools?
- What information do you wish was easier to access?
- What coordination problems do you face with friends or family?

**Ask people about their frustrations:**
- "What's the most annoying part of your day?"
- "What task do you dread doing?"
- "What do you wish there was an app for?"
- "What spreadsheet or notes system are you maintaining manually?"

### Red Flags (Avoid These Ideas)

- "Everyone will use this" - If everyone is your user, no one is
- "I'll build it and they will come" - Requires users BEFORE you build
- Ideas you wouldn't personally use - Hard to stay motivated

### Green Flags (Good Ideas)

- You are the first user - You'll actually use it
- Solves a specific pain point - Not just "would be nice to have"
- 1-10 potential users you can name - Know exactly who needs this
- Simple core feature - Can be built in 2-3 weeks

## Finding Your First Users

You need at least 1 real user (ideally you). Here's how to find them:

### 1. Start With Yourself

**Best approach:** Build something YOU need and will use daily.

Examples:
- Track your own workout progress
- Organize your own recipe collection
- Manage your own study schedule
- Track expenses with your roommates

### 2. Ask Friends and Family

**Reach out directly:**
- Text 5-10 friends: "I'm building [X]. Would you actually use it?"
- Ask specific follow-up: "How often would you use it?"
- Get commitment: "Can I send you a link when it's ready?"

**Look for genuine interest, not polite support.**

### 3. Use Your Network

- Post on LinkedIn: "Building [X]. Looking for 5 people who [have this problem]."
- Message classmates or study group members in similar situations
- Post in Discord/Slack communities
- Be specific about the problem and ask for early testers

### 4. Meetup/Local Communities

- Find local meetup groups
- Check campus clubs related to your idea
- Visit places where your users hang out

## Validating Your Idea (Before You Build)

Talk to 3-5 potential users and ask: "Do you have this problem? How do you solve it now? Would you use an app weekly/daily?"

If you get 3+ saying "Yes, I'd definitely use this" AND your instructor approves the technical scope - BUILD IT.

## Next Steps (2-3 Hours Over 2-3 Days)

**Day 1 (10m-1 hour):**
1. Brainstorm 3-5 pain points you or others experience
2. Pick your top 2 ideas

**Day 2 (1 hour):**
3. Talk to 3-5 potential users about each idea
4. Pick the idea with the most genuine interest

**Day 3 (30 min - 1 hour):**
5. Get commitments from 1-3 people to test it
6. Get instructor approval on technical scope
7. Start building the simplest version

Remember: A simple app with 1 real user is better than a complex app with zero users.
