## 1. Setup Your Project Planning Tool

Choose ONE of the following options to track your Sprint 0 work:

**Option A: Trello (Recommended for beginners)**

- Create a free Trello account at https://trello.com
- **Clone the Sprint 0 template:**
  - Go to the [Trello Template](https://trello.com/invite/b/690f96f99012bcaba09b4c28/ATTI95f6baceedd1f6310f955ea03fcf9dd14D9F3903/final-project)
  - Go to top of screen and click "Create Board from Template"
  - Name your board "Final Project - Sprint 0"
- **IMPORTANT:** The template references two files located on OneDrive for this week:
  - User Stories Template: `user-stories-template.md`
  - Project Idea Discovery: `project-idea-and-user-discovery.md`

**Option B: Other Project Management Software**

- Jira, Monday, Asana, ClickUp, Linear, etc.
- Manually copy the chores from the `sprint-0/` folder into your chosen tool
- Organize into two lists: "Pre-Sprint 0: Planning Chores" and "Sprint 0: Technical Setup Chores"

**Option C: Manual Tracking**

- Use a pen/paper planner or a simple document
- Copy the checklists from each file in the `sprint-0/` folder

## 2. Reference the Step-by-Step Guides

For Setup Chores (SC1-SC4), use the detailed step-by-step guides for better guidance:

- **Setup Chore 1 (GitHub Repository):** Use `[Sprint-0]-chore-12-github-repository-step-by-step.md`
- **Setup Chore 2 (React Frontend):** Use `[Sprint-0]-chore-13-initialize-react-frontend-step-by-step.md`
- **Setup Chore 3 (Express Backend):** Use `[Sprint-0]-chore-14-initialize-express-backend-step-by-step.md`

These step-by-step guides provide detailed terminal commands, expected outputs, and troubleshooting tips for each technical setup task.

## 3. Important Notes

- When creating new cards during Sprint 0, use descriptive names that help you track progress
- If using a single board for all sprints, consider using labels (Sprint-0, Sprint-1, Sprint-2) to organize cards
- Reference the source files in the `sprint-0/` folder for the most up-to-date chore details
