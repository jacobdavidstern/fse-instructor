# Chore 1: Project Selection

**Estimated Time:** 2-3 hours

## Task
Choose your project and validate the idea

## Steps

- [ ] Review three project options (Task Management, Content Sharing, Custom)
- [ ] **(For Option 3 - Custom Project):** Follow [Project Idea and User Discovery Plan](../project-idea-and-user-discovery.md)
- [ ] **(For Option 3):** Brainstorm 3-5 pain points you or others experience
- [ ] **(For Option 3):** Talk to 3-5 potential users to validate ideas
- [ ] **(For Option 3):** Pick the idea with the most genuine interest
- [ ] Document your decision in README.md: What problem does this solve?
- [ ] Time box: If you can't find an idea quickly, choose Option 1 or 2

## Acceptance Criteria

- [ ] Project option selected (1, 2, or 3)
- [ ] Problem statement documented
- [ ] (For Option 3) At least 3 potential users validated the need
- [ ] Instructor approval obtained
