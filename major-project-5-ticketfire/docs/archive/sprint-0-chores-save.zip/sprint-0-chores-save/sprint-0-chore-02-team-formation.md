# Chore 2: Team Formation

**Estimated Time:** 30 minutes

## Task
Decide if working solo or with partner, establish collaboration plan

## Steps

- [ ] Decide: Working solo or with a partner?
- [ ] If partnering: Discuss workload split (frontend/backend, features)
- [ ] If partnering: Agree on meeting schedule (daily standup time)
- [ ] If partnering: Set up communication channels (Discord, Slack, etc.)
- [ ] Document team roles and responsibilities (its expected that you are both able to do full stack feature work so you can talk about this during interviews)

## Acceptance Criteria

- [ ] Team composition decided
- [ ] (If partnering) Roles and workload split agreed upon
- [ ] (If partnering) Communication schedule established
