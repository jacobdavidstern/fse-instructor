# sprint-0-chore-01-project-selection.md
# Chore 1: Project Selection

**Estimated Time:** 2-3 hours

## Task
Choose your project and validate the idea

## Steps

- [ ] Review three project options (Task Management, Content Sharing, Custom)
- [ ] **(For Option 3 - Custom Project):** Follow [Project Idea and User Discovery Plan](../project-idea-and-user-discovery.md)
- [ ] **(For Option 3):** Brainstorm 3-5 pain points you or others experience
- [ ] **(For Option 3):** Talk to 3-5 potential users to validate ideas
- [ ] **(For Option 3):** Pick the idea with the most genuine interest
- [ ] Document your decision in README.md: What problem does this solve?
- [ ] Time box: If you can't find an idea quickly, choose Option 1 or 2

## Acceptance Criteria

- [ ] Project option selected (1, 2, or 3)
- [ ] Problem statement documented
- [ ] (For Option 3) At least 3 potential users validated the need
- [ ] Instructor approval obtained

# sprint-0-chore-02-team-formation.md
# Chore 2: Team Formation

**Estimated Time:** 30 minutes

## Task
Decide if working solo or with partner, establish collaboration plan

## Steps

- [ ] Decide: Working solo or with a partner?
- [ ] If partnering: Discuss workload split (frontend/backend, features)
- [ ] If partnering: Agree on meeting schedule (daily standup time)
- [ ] If partnering: Set up communication channels (Discord, Slack, etc.)
- [ ] Document team roles and responsibilities (its expected that you are both able to do full stack feature work so you can talk about this during interviews)

## Acceptance Criteria

- [ ] Team composition decided
- [ ] (If partnering) Roles and workload split agreed upon
- [ ] (If partnering) Communication schedule established

# sprint-0-chore-03-identify-users.md
# Chore 3: Identify Users

**Estimated Time:** 1 hour

## Task
Find real users who will test your application

## Steps

- [ ] Identify your first user (ideally you)
- [ ] List 3-5 potential users by name
- [ ] **(For Option 3):** Reach out via text, LinkedIn, Discord communities
- [ ] Get commitment from at least 1 person to test your app
- [ ] Document: How will they use it? How often (daily/weekly)?
- [ ] Verify users genuinely need the app (not just being polite)

## Acceptance Criteria

- [ ] At least 1 real user identified
- [ ] 3-5 potential users listed
- [ ] User needs documented
- [ ] Testing commitments secured

# sprint-0-chore-04-define-core-features.md
# Chore 4: Define Core Features and MVP

**Estimated Time:** 1-2 hours

## Task
Identify MVP features, prioritize them, and write clear MVP description

## Steps

### Part 1: Core Features (MVP vs Nice-to-Have)
- [ ] Brainstorm ALL possible features you could build
- [ ] For EACH feature, ask: "If this feature was missing, would my users still get value from the app?"
  - If YES → Nice-to-Have
  - If NO → MVP Feature
- [ ] Label 3-5 features as **MVP Features** (must have for launch)
- [ ] Label all other features as **Nice-to-Have** or **Future Enhancement**
- [ ] Verify MVP features can be built in 2-3 weeks
- [ ] Create features list in a document or README with clear labels

**Example:**
```
MVP Features (Must Have):
- User registration and login
- Create new task
- View task list
- Mark task as complete
- Delete task

Nice-to-Have Features (Future):
- Task categories/tags
- Due dates and reminders
- Task priority levels
- Share tasks with other users
- Dark mode
```

### Part 2: Define MVP
- [ ] Write 2-3 sentence MVP description
- [ ] Example: "Users can register, login, create tasks, mark them complete, and view their task list. That's it."
- [ ] Verify: "Can a user get value from JUST these core features?" (Must be YES)
- [ ] Document MVP in README or planning doc
- [ ] Get instructor approval on MVP scope

## Acceptance Criteria

- [ ] Complete feature list created with clear labels
- [ ] 3-5 core MVP features identified and labeled as "MVP Features"
- [ ] Non-essential features clearly labeled as "Nice-to-Have"
- [ ] Each feature passes the test: "Would users still get value without this?"
- [ ] MVP features are realistic for 2-3 week timeline
- [ ] MVP description written (2-3 sentences)
- [ ] MVP provides clear user value
- [ ] Scope is realistic for 2-3 weeks
- [ ] Instructor approved MVP

# sprint-0-chore-05-create-mockups-wireframes.md
# Chore 5: Create Mockups Wireframes Colors and Fonts

**Estimated Time:** 1-2 hours

## Task
Design basic layout for all 5 required pages and select design system (colors and fonts)

## Steps

### Part 1: Mockups and Wireframes
- [ ] Choose tool: Paper, Figma, Excalidraw, or drawing app
- [ ] Sketch/wireframe 5 required pages:
  - Landing/Home page
  - Login page
  - Registration page
  - Dashboard/Main app page
  - User profile or settings page
- [ ] Focus on layout and user flow, not pixel-perfect design
- [ ] Show navigation between pages
- [ ] Identify where CRUD operations happen
- [ ] Save mockups (photo, export, or screenshot)

### Part 2: Color Palette
- [ ] Choose color palette (8-12 colors) using:
  - Coolors.co - https://coolors.co/
  - Adobe Color - https://color.adobe.com/
  - Tailwind Color Generator - https://uicolors.app/create
- [ ] Select 2-3 primary colors, 3-4 neutrals, 4 semantic colors
- [ ] Document color hex codes

### Part 3: Font Selection
- [ ] Choose font option:
  - System fonts (fastest, no setup)
  - Google Fonts (1-2 fonts max) - https://fonts.google.com/
- [ ] If using Google Fonts, select:
  - 1 font for headings
  - 1 font for body text (or use same font with different weights)
- [ ] Document font names and weights

## Acceptance Criteria

- [ ] All 5 pages have mockups/wireframes
- [ ] Navigation flow is clear
- [ ] Main features are visible in designs
- [ ] Mockups saved and accessible
- [ ] Color palette selected (8-12 colors with hex codes)
- [ ] Font selection documented

# sprint-0-chore-06-ui-design-system.md
# Chore 6: Choose UI Framework and Icons

**Estimated Time:** 30-45 minutes

## Task
Choose UI component library and icon library for consistent design

## Steps

- [ ] Choose ONE component library or CSS framework:
  - React Bootstrap - https://react-bootstrap.github.io/
  - Tailwind CSS - https://tailwindcss.com/
  - DaisyUI - https://daisyui.com/
  - Ant Design - https://ant.design/
- [ ] Document your choice and reasoning
- [ ] Choose icon library (if needed):
  - React Icons - https://react-icons.github.io/react-icons/
  - Font Awesome - https://fontawesome.com/
- [ ] Document all UI choices in README or DESIGN.md
- [ ] List installation commands for later reference

## Acceptance Criteria

- [ ] Component library/framework chosen and documented
- [ ] Icon library chosen (if needed)
- [ ] Installation commands listed
- [ ] All UI choices documented in README or DESIGN.md

# sprint-0-chore-07-component-architecture.md
# Chore 7: Plan Component Architecture (Simplified)

**Estimated Time:** 45 minutes - 1 hour (TIME-BOXED)

## Task
Break down your UI into components and plan state management strategy

## Recommended Reading
**Before starting, review:** Thinking in React - https://react.dev/learn/thinking-in-react

## Steps

### Part 1: Identify Components (20 minutes - TIME-BOXED)
- [ ] Review your mockups from Planning Chore 5
- [ ] For each page, identify UI components by drawing boxes around them
- [ ] Name each component (Navigation, TaskCard, LoginForm, etc.)
- [ ] Identify which components can be reused across pages
- [ ] List 5-8 main components with brief description
- [ ] Stop after 20 minutes - you can refine during coding

**Quick Component Checklist:**
- Navigation/Header
- Form components (Login, Register, Create/Edit)
- List/Card components (display your main resource)
- Button components
- Any modals or dialogs

### Part 2: Plan State Location (15 minutes - TIME-BOXED)
- [ ] For each component, ask: "What data does this need?"
- [ ] Identify where state should live:
  - **Local state:** Form inputs, toggles, component-specific data
  - **Shared state:** User authentication, data shown across multiple components
- [ ] Mark which components will fetch data from API
- [ ] Stop after 15 minutes - you can adjust during coding

### Part 3: Choose State Management Strategy (10 minutes)

**State Management Guidelines:**

**Use Props Drilling when:**
- Passing data 2-3 levels deep maximum
- Simple, straightforward data flow
- WARNING: Can create tightly coupled components if overused

**Use Context API (useContext) when:**
- State needed across most or all of your app
- Examples: AuthContext (user login state), ThemeContext (dark mode)
- Good for: Authentication, user preferences, theme

**Use Custom Hooks when:**
- Reusing stateful logic across components
- Examples: useFetch, useAuth, useLocalStorage
- Keeps components clean and logic reusable

**Use State Management Libraries (Redux/Zustand) when:**
- Lots of state that isn't immediately saved by API
- Examples: Offline applications, complex forms with rollback
- Complex state updates across many components
- NOT NEEDED for most projects - start simple first

**Decision:**
- [ ] Document which approach you'll use for authentication
- [ ] Document which approach you'll use for your main resource data
- [ ] Keep it simple - you can always refactor later

## Example Component Plan

```
Pages and Components:

1. Home Page
   - Navigation (shared component)
   - HeroSection
   - FeatureList

2. Login Page
   - Navigation (shared component)
   - LoginForm (local state: email, password)

3. Dashboard Page
   - Navigation (shared component)
   - TaskList (fetches tasks from API)
   - TaskCard (receives task as prop)
   - CreateTaskButton

State Management:
- AuthContext: User login state (global - used in Navigation, Dashboard)
- Local state: Form inputs, individual component toggles
- API calls: Dashboard fetches tasks, stores in local state
```

## Acceptance Criteria

- [ ] 5-8 main components identified and named
- [ ] Reusable components marked (used on multiple pages)
- [ ] State location decided (local vs shared)
- [ ] State management strategy chosen for:
  - Authentication state
  - Main resource data
- [ ] Component plan documented (can be simple list or sketch)
- [ ] TIME-BOXED: Stopped after 45 minutes to 1 hour

## Important Note

This is a PLANNING exercise, not final architecture. You will refine and adjust as you code. The goal is to think through the basics so you can start coding with direction, not to create a perfect plan. Keep it simple and move forward.

# sprint-0-chore-08-write-user-stories.md
# Chore 8: Write User Stories

**Estimated Time:** 2-3 hours

## Task
Create user stories for each feature with acceptance criteria

## Steps

- [ ] Use the [User Stories Template](../user-stories-template.md)
- [ ] Write stories for authentication (registration, login, protected routes)
- [ ] Write stories for CRUD operations on main resource
- [ ] Write stories for additional core features
- [ ] Include acceptance criteria for each story
- [ ] Estimate time for each story (in hours)
- [ ] Prioritize stories (1 = highest priority)
- [ ] Total estimated hours should be ~30-40 hours

## Acceptance Criteria

- [ ] All core features have user stories
- [ ] Each story has acceptance criteria
- [ ] Each story has time estimate
- [ ] Stories are prioritized
- [ ] Total estimate is 30-40 hours

# sprint-0-chore-09-design-database-schema.md
# Chore 9: Design Database Schema

**Estimated Time:** 1-2 hours

## Task
Design database models and relationships before coding

## Steps

- [ ] Identify all data entities needed (User, main resource, related entities)
- [ ] Choose modeling tool:
  - **MongoDB Modeler:** https://mongomodeler.com/editor.html (visual design for MongoDB schemas)
  - Paper/whiteboard sketch
  - Draw.io or Lucidchart
  - Excalidraw
- [ ] Design User model with fields:
  - username (String, required, unique)
  - email (String, required, unique)
  - password (String, required, hashed)
  - createdAt (Date)
- [ ] Design main resource model with fields and validation rules
- [ ] Define relationships between models:
  - User has many [resources]
  - Use foreign keys (SQL) or references (MongoDB)
- [ ] Identify required fields vs optional fields
- [ ] Define data types for all fields
- [ ] Save schema design (screenshot, export, or document)
- [ ] Verify minimum 2 models with relationships (rubric requirement)

## Acceptance Criteria

- [ ] Minimum 2 models designed (User + main resource)
- [ ] All fields have data types specified
- [ ] Relationships between models defined
- [ ] Required vs optional fields identified
- [ ] Validation rules documented
- [ ] Schema design saved and accessible

# sprint-0-chore-10-sprint-planning.md
# Chore 10: Sprint Planning

**Estimated Time:** 30 minutes

## Task
Group user stories into Sprint 1 and Sprint 2

## Steps

- [ ] Review all user stories
- [ ] Group into Sprint 1 (Backend/Database/Auth):
  - Database models (based on schema design from Planning Chore 10)
  - Authentication routes
  - CRUD API routes
  - Security implementation
- [ ] Group into Sprint 2 (Frontend/Integration):
  - React component architecture (based on Planning Chore 7)
  - React pages and routing
  - Authentication UI and state management
  - CRUD operations UI
  - Styling and responsive design (based on Planning Chore 5 & 6)
- [ ] Verify Sprint 1: 15-20 hours, Sprint 2: 18-25 hours
- [ ] Document sprint backlog

## Acceptance Criteria

- [ ] All stories assigned to Sprint 1 or Sprint 2
- [ ] Sprint 1 focuses on backend
- [ ] Sprint 2 focuses on frontend
- [ ] Time estimates are balanced

# sprint-0-chore-11-github-repository.md
# Chore 11: Create GitHub Repository and Project Structure

**Estimated Time:** 15 minutes

## Task
Set up version control and create project folders

## Steps

- [ ] Create new GitHub repository (public)
- [ ] Initialize with README.md
- [ ] Add .gitignore for Node.js and React
- [ ] Clone repository to local machine
- [ ] Create `client/` folder in project root
- [ ] Create `server/` folder in project root
- [ ] Verify Git is working: `git status`

## Project Structure

```
your-project/
├── client/         (React frontend)
├── server/         (Express backend)
├── .gitignore
└── README.md
```

## Acceptance Criteria

- [ ] Repository exists on GitHub
- [ ] Local clone is working
- [ ] .gitignore includes node_modules/, .env, .DS_Store
- [ ] client/ and server/ folders created

# sprint-0-chore-12-initialize-react-frontend.md
# Chore 12: Initialize React Frontend

**Estimated Time:** 15-20 minutes

## Task
Set up React application with routing, HTTP client, and proper folder structure

## Steps

### Part 1: Create React App
- [ ] Navigate to project root
- [ ] Run: `npm create vite@latest client -- --template react`
- [ ] Navigate to client folder: `cd client`
- [ ] Install dependencies: `npm install`

### Part 2: Install Core Dependencies
- [ ] Install routing and HTTP client:
  ```bash
  npm install react-router axios
  ```

### Part 3: Install Styling Framework and Icons (from Planning Chore 6)
- [ ] Follow installation instructions based on your Planning Chore 6 decision:
  - **React Bootstrap:** https://react-bootstrap.github.io/docs/getting-started/introduction
  - **Tailwind CSS:** https://tailwindcss.com/docs/guides/vite
  - **DaisyUI:** https://daisyui.com/docs/install/
  - **Ant Design:** https://ant.design/docs/react/introduce
- [ ] Follow icon library installation instructions (if chosen in Planning Chore 6):
  - **React Icons:** https://react-icons.github.io/react-icons/
  - **Font Awesome:** https://docs.fontawesome.com/web/use-with/react/

### Part 4: Add Google Fonts (from Planning Chore 5)
- [ ] If using Google Fonts, follow the instructions at: https://fonts.google.com/
- [ ] Add the `<link>` tag to `index.html` in `<head>` section
- [ ] Update `src/index.css` with your chosen font-family

### Part 5: Create Folder Structure
- [ ] Navigate to `src` folder: `cd src`
- [ ] Create project folders:
  ```bash
  mkdir components pages hooks context utils
  ```
- [ ] Folder structure should look like:
  ```
  src/
  ├── components/    (Reusable UI components)
  ├── pages/         (Route-level page components)
  ├── hooks/         (Custom React hooks)
  ├── context/       (React Context for state management)
  ├── utils/         (Helper functions)
  ├── App.jsx
  ├── App.css
  ├── main.jsx
  └── index.css
  ```

### Part 6: Test Setup
- [ ] Navigate back to client folder: `cd ..`
- [ ] Test: `npm run dev`
- [ ] Verify React app opens in browser at http://localhost:5173
- [ ] Stop the dev server (Ctrl+C)

## Acceptance Criteria

- [ ] React app created successfully with Vite
- [ ] react-router installed
- [ ] axios installed
- [ ] Styling framework/library installed (from Planning Chore 6)
- [ ] Icon library installed (if chosen in Planning Chore 6)
- [ ] Google Fonts added (if chosen in Planning Chore 5)
- [ ] All folders created (components, pages, hooks, context, utils)
- [ ] App runs without errors
- [ ] Default React page displays in browser at http://localhost:5173

# sprint-0-chore-13-initialize-express-backend.md
# Chore 13: Initialize Express Backend with Folder Structure

**Estimated Time:** 15 minutes

## Task
Set up Express server, install dependencies, create folder structure, and add a test route

## Steps

- [ ] Navigate to server folder: `cd server`
- [ ] Initialize npm: `npm init -y`
- [ ] Install backend dependencies:
  ```bash
  npm install express dotenv cors bcrypt jsonwebtoken
  ```
- [ ] Install security dependencies:
  ```bash
  npm install helmet express-rate-limit
  ```
- [ ] Install database dependency (choose one):
  ```bash
  # For MongoDB:
  npm install mongoose

  # For PostgreSQL/MySQL:
  npm install sequelize pg
  # OR
  npm install sequelize mysql2
  ```
- [ ] Install dev dependencies:
  ```bash
  npm install --save-dev nodemon
  ```
- [ ] Update package.json scripts:
  ```json
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  }
  ```
- [ ] Create folder structure:
  ```bash
  mkdir models routes middleware config controllers utils
  ```
- [ ] Create `.env` file in server folder with:
  ```
  PORT=3001
  NODE_ENV=development
  DATABASE_URL=temporary_placeholder
  JWT_SECRET=temporary_placeholder
  ```
- [ ] Create `.env.example` file in server folder:
  ```
  PORT=3001
  NODE_ENV=development
  DATABASE_URL=your_mongodb_connection_string
  JWT_SECRET=your_jwt_secret_here
  ```
- [ ] Create `server.js` file with basic Express setup and test route:
  ```javascript
  require('dotenv').config();
  const express = require('express');
  const cors = require('cors');
  const helmet = require('helmet');

  const app = express();

  // Middleware
  app.use(helmet());
  app.use(cors());
  app.use(express.json());

  // Test route
  app.get('/api/test', (req, res) => {
    res.json({ message: 'Backend is working!' });
  });

  const PORT = process.env.PORT || 3001;
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  ```
- [ ] Test server: `npm run dev`
- [ ] Verify server starts without errors
- [ ] Test route in browser: http://localhost:3001/api/test
- [ ] Stop the dev server (Ctrl+C)

## Folder Structure

```
server/
├── models/         (Database schemas/models)
├── controllers/    (Business logic for routes)
├── routes/         (API route handlers)
├── middleware/     (Authentication, validation, error handling)
├── config/         (Database connection, config files)
├── utils/          (Helper functions, validators, token generators)
├── server.js       (Main server file)
├── .env            (Environment variables - NOT committed)
├── .env.example    (Example env file - committed)
└── package.json
```

## Acceptance Criteria

- [ ] package.json created in server folder
- [ ] All core dependencies installed (express, dotenv, cors, bcrypt, jsonwebtoken)
- [ ] All security dependencies installed (helmet, express-rate-limit)
- [ ] Database ORM installed (mongoose OR sequelize)
- [ ] nodemon installed as dev dependency
- [ ] Scripts added to package.json
- [ ] All folders created (models, controllers, routes, middleware, config, utils)
- [ ] .env and .env.example files created
- [ ] server.js created with test route
- [ ] Server runs successfully on port 3001
- [ ] Test route returns JSON response

# sprint-0-chore-14-database-setup.md
# Chore 14: Set Up Database and Test Connection

**Estimated Time:** 20-30 minutes

## Task
Create database instance, configure environment variables, and verify connection

## For MongoDB Atlas

- [ ] Sign up for MongoDB Atlas (https://www.mongodb.com/cloud/atlas)
- [ ] Create new cluster (free tier)
- [ ] Create database user with username/password
- [ ] Whitelist IP address (allow access from anywhere: 0.0.0.0/0)
- [ ] Get connection string
- [ ] Update `.env` file with actual connection string:
  ```
  DATABASE_URL=mongodb+srv://username:password@cluster.mongodb.net/your-database-name
  ```
- [ ] Generate strong JWT secret (random string, 32+ characters)
- [ ] Update `.env` file with JWT secret:
  ```
  JWT_SECRET=your_actual_random_secret_here
  ```
- [ ] Create `config/db.js` file:
  ```javascript
  const mongoose = require('mongoose');

  const connectDB = async () => {
    try {
      await mongoose.connect(process.env.DATABASE_URL);
      console.log('MongoDB connected successfully');
    } catch (error) {
      console.error('MongoDB connection error:', error.message);
      process.exit(1);
    }
  };

  module.exports = connectDB;
  ```
- [ ] Update `server.js` to connect to database:
  ```javascript
  require('dotenv').config();
  const express = require('express');
  const cors = require('cors');
  const helmet = require('helmet');
  const connectDB = require('./config/db');

  const app = express();

  // Connect to database
  connectDB();

  // Middleware
  app.use(helmet());
  app.use(cors());
  app.use(express.json());

  // Test route
  app.get('/api/test', (req, res) => {
    res.json({ message: 'Backend is working!' });
  });

  const PORT = process.env.PORT || 3001;
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  ```
- [ ] Test database connection: `npm run dev`
- [ ] Verify console shows "MongoDB connected successfully"
- [ ] Stop the dev server (Ctrl+C)

## For Local MongoDB

- [ ] Install MongoDB Community Edition
- [ ] Start MongoDB service: `brew services start mongodb-community` (macOS)
- [ ] Update `.env` with connection string:
  ```
  DATABASE_URL=mongodb://localhost:27017/your-database-name
  ```
- [ ] Follow same steps above to create config/db.js and update server.js
- [ ] Test database connection

## For PostgreSQL/MySQL (only applies to non-Mongo-db users)

- [ ] Install PostgreSQL or MySQL locally
- [ ] Create new database
- [ ] Note username, password, database name
- [ ] Update `.env` with connection string
- [ ] Create config/db.js with Sequelize connection
    - see https://sequelize.org/docs/v6/getting-started/
- [ ] Update server.js to connect to database
- [ ] Test database connection

## Commit to GitHub

- [ ] Navigate to project root
- [ ] Stage all files: `git add .`
- [ ] Check status: `git status` (verify .env is NOT staged)
- [ ] Commit: `git commit -m "Initial project setup with client and server structure"`
- [ ] Push to GitHub: `git push origin main`
- [ ] Verify commit appears on GitHub

## Acceptance Criteria

- [ ] Database instance created (MongoDB Atlas or local)
- [ ] .env file updated with actual DATABASE_URL
- [ ] .env file updated with strong JWT_SECRET (32+ characters)
- [ ] config/db.js created with connection logic
- [ ] server.js updated to connect to database
- [ ] Server starts successfully and connects to database
- [ ] Console shows successful connection message
- [ ] All files committed (except .env)
- [ ] .env is NOT in Git
- [ ] .env.example IS in Git
- [ ] Commit pushed to GitHub

