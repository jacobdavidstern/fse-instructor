# Chore 11: Create GitHub Repository and Project Structure

**Estimated Time:** 15 minutes

## Task
Set up version control and create project folders

## Steps

- [ ] Create new GitHub repository (public)
- [ ] Initialize with README.md
- [ ] Add .gitignore for Node.js and React
- [ ] Clone repository to local machine
- [ ] Create `client/` folder in project root
- [ ] Create `server/` folder in project root
- [ ] Verify Git is working: `git status`

## Project Structure

```
your-project/
├── client/         (React frontend)
├── server/         (Express backend)
├── .gitignore
└── README.md
```

## Acceptance Criteria

- [ ] Repository exists on GitHub
- [ ] Local clone is working
- [ ] .gitignore includes node_modules/, .env, .DS_Store
- [ ] client/ and server/ folders created
