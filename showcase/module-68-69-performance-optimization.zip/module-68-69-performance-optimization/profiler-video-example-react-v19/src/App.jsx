// src/App.jsx

import { useState, useReducer } from 'react';
import { ArticleStats } from './components/ArticleStats.jsx';
import './App.css';
import Logo from './logo.svg';

export default function App() {
  const [text, setText] = useState('');
  const [showExplanation, toggleExplanation] = useReducer(
    (state) => !state,
    false
  );

  return (
    <div className="container">
      <img src={Logo} alt="logo" className="logo" />
      <label htmlFor="text">
        <textarea
          aria-label="Area to add text"
          id="text"
          name="text"
          rows="10"
          className="article"
          onChange={(event) => setText(event.target.value)}
        ></textarea>
      </label>
      <div className="stats">
        {/* performance issue on next line, see src/helpers/index.js for loop */}
        <ArticleStats showExplanation={showExplanation} text={text} />
        <div className="show-explanation">
          <button onClick={toggleExplanation}>What are these stats?</button>
        </div>
      </div>
    </div>
  );
}

{
  /*
  PERFORMANCE IDEAS (Student-Friendly)

  The Big Idea:
  - You can speed things up by changing WHEN state updates happen,
    or by changing WHERE the expensive work happens.
  - These are two different strategies.

  1. startTransition(setText)
     - Delays the re-render caused by typing.
     - Makes the textarea feel smooth.
     - ArticleStats still runs on every keystroke, just later.
     - This is "optimizing the state update."

  2. Deferring work inside ArticleStats
     - App updates right away, but ArticleStats does its heavy work in the background.
     - Only the slow component is delayed.
     - This is "optimizing the component."
     - Add pending visual for consistent feedback.

  3. useMemo
     - Remembers expensive results so they don’t re-run unnecessarily.
     - Good for pure calculations.

  4. React.memo
     - Prevents a component from re-rendering unless its props change.
     - Helps when the component is visually heavy.

  5. Web Worker
     - Moves heavy CPU work off the main thread entirely.
     - Best for really expensive calculations.

  6. Throttle / Debounce
     - Limits how often the expensive work runs.
     - Useful when real-time updates aren’t required.

  TL;DR:
  - startTransition → smoother typing.
  - Defer inside ArticleStats → isolate the slow part.
  - Memoization → avoid unnecessary work.
  - Web Worker → maximum performance.
*/
}
