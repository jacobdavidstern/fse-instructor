// controllers/resourcesController.js
