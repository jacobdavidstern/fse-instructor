// Note: useState does is unneeded and does not belong in this file
// import { useState } from 'react';
import './App.css';
import ProductList from './components/ProductList';
import PizzaMenu from './components/PizzaMenuStarter';
import PizzaMenuUseState from './components/PizzaMenuUseState';
import SignUpForm from './components/SignUpForm';

function App() {
  // const [count, setCount] = useState(0);

  return (
    <>
      {/* <StaticProductList /> */}
      <ProductList />
      <PizzaMenu />
      <PizzaMenuUseState />
      <SignUpForm />
    </>
  );
}

export default App;
