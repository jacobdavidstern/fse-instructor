// Post.jsx Page
// Renders a full microblog post

import { useParams, Link } from 'react-router-dom';
import { getPostById } from '../data/posts.js';

export default function Post() {
  const { id } = useParams(); // read /posts/:id
  const post = getPostById(id); // lookup post by pid

  if (!post) {
    return (
      <div className="post-not-found">
        <h2>Post not found</h2>
        <Link to="/posts">Back to Feed</Link>
      </div>
    );
  }

  return (
    <div className="post-page">
      <h1>{post.title}</h1>
      <p className="post-user">by User ID: {post.uid}</p>
      <div className="post-body">{post.body}</div>
      <p className="post-tags">Tags: {post.tags.join(', ')}</p>
      <p className="post-timestamp">
        Posted on: {new Date(post.createdAt).toLocaleString()}
      </p>
      <Link to="/posts" className="back-link">
        Back to Feed
      </Link>
    </div>
  );
}
