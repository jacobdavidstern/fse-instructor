// Create.jsx Page
// Protected page for creating a new post

import CreatePost from '../components/CreatePost.jsx';

export default function Create() {
  return (
    <div className="create-page">
      <h1>Create a New Post</h1>
      <CreatePost />
    </div>
  );
}
