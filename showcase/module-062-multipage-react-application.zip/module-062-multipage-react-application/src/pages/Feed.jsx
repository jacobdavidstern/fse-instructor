// Feed.jsx Page
// Render feed of all Devvit microblogs

import { posts } from '../data/posts.js';
import PostCard from '../components/PostCard.jsx';

export default function Feed() {
  return (
    <div className="feed">
      {posts.map((post) => (
        <PostCard key={post.pid} post={post} />
      ))}
    </div>
  );
}
