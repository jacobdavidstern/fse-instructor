// Profile Page - A protected route demonstrating authentication

function Profile() {
  return (
    <div className="page">
      <h1>Profile</h1>
      <p>Welcome! This is a protected page.</p>
      <p>You can only see this because you're logged in.</p>

      <div className="profile-card">
        <h2>Quick Stats</h2>
        <div className="stats-grid">
          <div className="stat-item">
            <div className="stat-value">4</div>
            <div className="stat-label">Posts</div>
          </div>
          <div className="stat-item">
            <div className="stat-value">8</div>
            <div className="stat-label">Tags</div>
          </div>
          <div className="stat-item">
            <div className="stat-value">16</div>
            <div className="stat-label">Replies</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Profile;
