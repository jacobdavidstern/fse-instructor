// App.jsx
// Sets up all routes including protected routes

import { useState } from 'react';
import { Routes, Route } from 'react-router-dom';

// Components
import Navigation from './components/Navbar.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

// Pages
import Feed from './pages/Feed.jsx';
import Post from './pages/Post.jsx';
import Login from './pages/Login.jsx';
import Create from './pages/Create.jsx';
import Profile from './pages/Profile.jsx';

// Styles
import './App.css';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => setIsLoggedIn(true);
  const handleLogout = () => setIsLoggedIn(false);

  return (
    <div className="app">
      <Navigation isLoggedIn={isLoggedIn} onLogout={handleLogout} />

      <main className="main-content">
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<Feed />} />
          <Route path="/posts/:id" element={<Post />} />
          <Route path="/login" element={<Login onLogin={handleLogin} />} />

          {/* Protected routes */}
          <Route
            path="/create"
            element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <Create />
              </ProtectedRoute>
            }
          />

          <Route
            path="/profile"
            element={
              <ProtectedRoute isLoggedIn={isLoggedIn}>
                <Profile />
              </ProtectedRoute>
            }
          />

          {/* Catch-all unmatched routes */}
          <Route
            path="*"
            element={
              <div className="page error-page">
                <h1>404: Page Not Found</h1>
              </div>
            }
          />
        </Routes>
      </main>

      {/* Footer */}
      <footer className="footer">
        <p>Module 062: Multipage React Application - Reddit clone</p>
      </footer>
    </div>
  );
}

export default App;
