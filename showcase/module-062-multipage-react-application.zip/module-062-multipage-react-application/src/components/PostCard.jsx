// PostCard.jsx Component
// Reusable card component for displaying posts
//
// Structure:
//
// ---------------------------
// |        Post Title       |
// |  by User ID: <userId>   |
// |-------------------------|
// | Post body content here. |
// | More content...         |
// |-------------------------|
// | Tags: tag1, tag2, tag3 |
// | Posted on: <timestamp>  |
// ---------------------------

import { Link } from 'react-router-dom';

export default function PostCard({ post }) {
  return (
    <div className="post-card">
      <h3 className="post-title">
        <Link to={`/posts/${post.pid}`}>{post.title}</Link>
      </h3>
      <p className="post-user">by User ID: {post.uid}</p>
      <p className="post-body">{post.body}</p>
      <p className="post-tags">Tags: {post.tags.join(', ')}</p>
      <p className="post-timestamp">
        Posted on: {new Date(post.createdAt).toLocaleString()}
      </p>
    </div>
  );
}
