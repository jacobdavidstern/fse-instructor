// CreatePost.jsx component
// Reusable form for creating a new post

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function CreatePost() {
  const navigate = useNavigate();

  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [tags, setTags] = useState('');

  function handleSubmit(e) {
    e.preventDefault();

    const newPost = {
      pid: Date.now(),
      uid: 1, // or whatever user ID you want
      title,
      body,
      tags: tags.split(',').map((t) => t.trim()),
      createdAt: Date.now(),
    };

    console.log('Created post:', newPost);

    navigate('/posts');
  }

  return (
    <form className="create-post-form" onSubmit={handleSubmit}>
      <label>
        Title:
        <input value={title} onChange={(e) => setTitle(e.target.value)} />
      </label>

      <label>
        Body:
        <textarea value={body} onChange={(e) => setBody(e.target.value)} />
      </label>

      <label>
        Tags:
        <input value={tags} onChange={(e) => setTags(e.target.value)} />
        <span className="hint">(comma‑separated)</span>
      </label>

      <button type="submit">Create Post</button>
    </form>
  );
}
