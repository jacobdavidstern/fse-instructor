// Navbar.jsx Component
// Navbar with Devvit logo link and login/out functionality

import { NavLink } from 'react-router-dom';

export default function Navbar({ isLoggedIn, onLogout }) {
  return (
    <nav className="navigation">
      <div className="nav-container">
        <div className="nav-brand">
          <NavLink to="/">Devvit</NavLink>
        </div>

        <ul className="nav-links">
          {/* Show profile link only when logged in */}
          {isLoggedIn && (
            <li>
              <NavLink to="/create">Create</NavLink>
            </li>
          )}

          {/* Show profile link only when logged in */}
          {isLoggedIn && (
            <li>
              <NavLink to="/profile">Profile</NavLink>
            </li>
          )}
        </ul>

        <div className="nav-auth">
          {isLoggedIn ? (
            <button onClick={onLogout} className="btn-logout">
              Logout
            </button>
          ) : (
            <NavLink to="/login" className="btn-login">
              Login
            </NavLink>
          )}
        </div>
      </div>
    </nav>
  );
}
