// Mock post data for demonstrating URL parameters

export const posts = [
  {
    pid: 1,
    uid: 101,
    title: 'First day learning React!',
    body: 'Finally diving into React and hooks. useState clicked instantly, but useEffect is still a bit mysterious.',
    tags: ['react', 'learning', 'webdev'],
    createdAt: '2025-01-02T10:15:00Z',
  },
  {
    pid: 2,
    uid: 102,
    title: 'Coffee vs Productivity',
    body: 'Is it just me, or does productivity peak exactly 12 minutes after the first sip of coffee?',
    tags: ['coffee', 'productivity'],
    createdAt: '2025-01-03T08:42:00Z',
  },
  {
    pid: 3,
    uid: 103,
    title: 'Minimalist Desk Setup',
    body: 'Swapped my dual monitors for a single ultrawide. My brain feels calmer already.',
    tags: ['minimalism', 'setup'],
    createdAt: '2025-01-04T14:20:00Z',
  },
  {
    pid: 4,
    uid: 101,
    title: 'Debugging at 2 AM',
    body: 'Found a missing semicolon after 45 minutes of existential dread. Classic.',
    tags: ['debugging', 'coding'],
    createdAt: '2025-01-05T02:13:00Z',
  },
  {
    pid: 5,
    uid: 104,
    title: 'What’s your favorite keyboard switch?',
    body: 'I’ve been using browns forever, but thinking about trying linears. Recommendations?',
    tags: ['keyboards', 'mechanical'],
    createdAt: '2025-01-06T17:55:00Z',
  },
];

// Helper: get post by ID
export function getPostById(pid) {
  return posts.find((post) => post.pid === parseInt(pid));
}

// Helper: get posts by user
export function getPostsByUser(uid) {
  return posts.filter((post) => post.uid === parseInt(uid));
}

// Helper: search posts by title or body
export function searchPosts(term) {
  if (!term) return posts;

  const lower = term.toLowerCase();
  return posts.filter(
    (post) =>
      post.title.toLowerCase().includes(lower) ||
      post.body.toLowerCase().includes(lower)
  );
}

// Helper: get all unique tags
export function getTags() {
  const tags = new Set();
  posts.forEach((post) => post.tags.forEach((tag) => tags.add(tag)));
  return [...tags].sort();
}
