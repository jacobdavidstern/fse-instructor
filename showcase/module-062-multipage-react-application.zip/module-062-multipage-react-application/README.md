# Devvit — A Microblog / Reddit‑Style Multi‑Page React App

Devvit is a lightweight microblogging application built as a multi‑page React project. It demonstrates routing, dynamic content, controlled forms, protected routes, and state management using React Hooks — all without external APIs or localStorage. The app uses mock data and in‑memory state to keep the architecture simple, predictable, and easy to grade.

This project began from an instructor demo and was heavily modified into a functional microblog with a feed, post detail pages, authentication simulation, and a post creation form.

## Features

Core Functionality

- Multi‑page React application using React Router
- Feed of posts rendered from mock data
- Dynamic post pages using useParams (/posts/:id)
- Create Post form with controlled inputs
- Protected routes (Create page requires login)
- Login simulation with app‑level auth state
- Responsive layout using React‑Bootstrap
- 404 Not Found fallback route

Architecture

- Clean component structure (components/ + pages/)
- App‑level state lifted appropriately for shared data
- Unidirectional data flow
- Multiple useEffect hooks with correct dependency arrays
- Cleanup patterns for side effects
- No infinite loops or lifecycle errors

What’s intentionally not included
To avoid unnecessary refactors and complexity:

- No localStorage
- No external API calls
- No persistent backend

All data lives in memory and resets on refresh — ideal for a controlled, low‑risk assessment project.

## Project Structure

```sh
Code
src/
├── App.css
├── App.jsx
├── main.jsx
│
├── components/
│   ├── CreatePost.jsx
│   ├── Navbar.jsx
│   ├── PostCard.jsx
│   └── ProtectedRoute.jsx
│
├── pages/
│   ├── Login/        ("/")
│   ├── Profile/      ("/profile")
│   ├── Feed/         ("/posts")
│   ├── Post/         ("/posts/:id")
│   ├── Create/       ("/create")
│   └── NotFound/     ("*")
│
└── data/
    └── Posts.js      (mock post data)
```

### Routing Overview

Route Component Description
/ Login Entry point, mock authentication
/profile Profile User profile page
/posts Feed List of all posts
/posts/:id Post Dynamic post detail page
/create CreatePost Protected route — requires login

- NotFound Fallback for invalid URLs

### Create Post Behavior

- The /create route includes a fully functional controlled form.
- Because the project intentionally avoids localStorage or a backend, new posts are added to in‑memory state only. Refreshing the page resets the data.

### Tech Stack

- React (Hooks, JSX, component architecture)
- React Router
- React‑Bootstrap
- Vite (build tooling)
- JavaScript (ES2025)

### Installation & Setup

```sh
npm install
npm run dev
The app runs on your local Vite dev server.
```
