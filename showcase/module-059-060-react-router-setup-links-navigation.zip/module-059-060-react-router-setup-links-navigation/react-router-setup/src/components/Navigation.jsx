import { Link } from 'react-router';

// Note: It would also be idiomatic to place ul's in parent component
export default function Navigation() {
  return (
    <nav>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/contact">Contact</Link>
        </li>
        <li>
          <Link to="/user-profile">User Profile</Link>
        </li>
        <li>
          <Link to="/user-profile/123">User Profile (ID: 123)</Link>
        </li>
      </ul>
    </nav>
  );
}
