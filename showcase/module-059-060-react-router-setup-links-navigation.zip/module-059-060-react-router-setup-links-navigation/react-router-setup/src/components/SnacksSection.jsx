export default function SnacksSection() {
  return (
    <div>
      <h2>Snacks Category</h2>
      <p>Browse our delicious selection of snacks!</p>
      <ul>
        <li>Chips - $2.99</li>
        <li>Cookies - $3.49</li>
        <li>Pretzels - $2.49</li>
        <li>Trail Mix - $4.99</li>
      </ul>
    </div>
  );
}
