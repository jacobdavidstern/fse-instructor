import { Route, Routes } from 'react-router-dom';
import './App.css';
import HomePage from './pages/HomePage';
import ContactPage from './pages/ContactPage';
import UserProfilePage from './pages/UserProfilePage';
import ProductsPage from './pages/ProductsPage';
import SnacksSection from './components/SnacksSection';
import NotFoundPage from './pages/NotFoundPage';

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/contact" element={<ContactPage />} />
        {/* :userId comes from the route in the address bar */}
        {/* http://localhost:5173/user-profile/1 */}
        {/* variable dynamically pulled from the route, called route parameter */}
        <Route path="/users/:userId" element={<UserProfilePage />} />

        {/* Parent route with nested child routes */}
        <Route path="/products" element={<ProductsPage />}>
          {/* Child route - renders inside the Outlet of ProductsPage */}
          <Route path="snacks" element={<SnacksSection />} />
        </Route>

        {/* Catch-all route (otherwise no bueno UX) - MUST be last! */}
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </>
  );
}

export default App;
