import { Outlet, Link } from 'react-router';
import Navigation from '../components/Navigation';

export default function ProductsPage() {
  return (
    <div>
      <Navigation />
      <h1>Our Products</h1>
      <div>
        <h3>Product Categories:</h3>
        <Link to="/products/snacks">Snacks</Link>
      </div>
      <hr />
      {/* This is where child routes will render */}
      <Outlet />
    </div>
  );
}
