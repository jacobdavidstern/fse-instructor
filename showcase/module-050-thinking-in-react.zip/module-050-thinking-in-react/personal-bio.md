## Thinking in React

Task - Rebuild your personal bio / other project.

1. Slice and dice a screenshot of your project, pretend like you don't know the structure.

## Step 2: Setup & Structure

### Create Vite Project

```bash
npm create vite@latest my-bio-page -- --template react
```

### Component Files (example)

```
src/
├── components/
│   ├── Header.jsx
│   ├── AboutSection.jsx
│   ├── SkillsSection.jsx
│   └── ContactSection.jsx
└── App.jsx
```

3. Make each component return <h1>ComponentName</h1>
4. Fill out each component
   // Use module 007 Personal Bio from Week 2, Session 1
5. Optional (add state to your components)
   // Added Light/Dark mode and an expanded About section with state
6. Continue to "Think in React" and do more advanced setup as we move into the projects.
