// ContactSection.jsx

export default function ContactSection() {
  return (
    <>
      <section id="contact">
        <h2>Let's Connect</h2>
        <div>
          Email:
          <a href="mailto:jds@email.com">jds@email.com</a>
        </div>
        <div>
          LinkedIn:
          <a href="https://www.linkedin.com/in/jds/">
            https://www.linkedin.com/in/jds/
          </a>
        </div>
        <div>
          GitHub:
          <a href="https://github.com/jds">https://github.com/jds</a>
        </div>

        <h3>Send me a Message</h3>
        <form action="/submit-survey" method="post">
          <div class="name-group">
            <div>
              <label for="firstname">First Name</label>
              <input
                type="text"
                name="firstname"
                id="firstname"
                placeholder="Enter your First Name"
              />
            </div>
            <div>
              <label for="lastname">Last Name</label>
              <input
                type="text"
                name="lastname"
                id="lastname"
                placeholder="Enter your Last Name"
              />
            </div>
          </div>
          <div>
            <label for="emailaddress">Email Address</label>
            <input
              type="email"
              name="emailaddress"
              id="emailaddress"
              placeholder="Enter your Email Address"
            />
          </div>
          <label for="message">Message:</label>
          <textarea
            id="message"
            name="message"
            rows="3"
            cols="64"
            placeholder="I'd love to hear from you"
          ></textarea>
          <div>
            <button type="submit">Submit</button>
          </div>
        </form>
      </section>
    </>
  );
}
