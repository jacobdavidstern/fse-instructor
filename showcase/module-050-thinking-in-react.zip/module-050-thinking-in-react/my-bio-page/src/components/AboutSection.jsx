// AboutSection.jsx
import { useState } from 'react';

function AboutSection() {
  const [expanded, setExpanded] = useState(false);

  return (
    <>
      <section id="about">
        <h2>About Me</h2>
        <img
          src="photo.webp"
          width="200"
          alt="Professional photo of Jacob Stern."
        />
        <p>
          I’ve always been a problem solver. My career in tech started in
          software support, where every day was about unraveling complex issues
          and helping customers. This taught me a lot about our software's inner
          workings and the value of communication and persistence.
        </p>
        {expanded && (
          <p>
            Eventually, I realized I wanted to build the solutions, not just fix
            them. I spent my free time learning to code, using my support
            experience to understand what users truly need. Now, as a software
            engineer, I’m thrilled to apply that knowledge to write better, more
            intuitive code.
          </p>
        )}
        <button onClick={() => setExpanded(!expanded)}>
          {expanded ? 'Show less' : 'Show more'}
        </button>
      </section>
    </>
  );
}
export default AboutSection;
