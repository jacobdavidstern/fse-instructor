// Header.jsx

export default function Header({ darkMode }) {
  return (
    <header>
      <h1 className={darkMode ? 'dark-text' : 'light-text'}>Jacob Stern</h1>
      <h2>Support Agent transitioning to Software Engineer</h2>
      <nav>
        <ul>
          <li>
            <a href="#about">About</a>
          </li>
          <li>
            <a href="#skills">Skills</a>
          </li>
          <li>
            <a href="#contact">Contact</a>
          </li>
        </ul>
      </nav>
    </header>
  );
}
