// SkillsSection.jsx

export default function SkillsSection() {
  return (
    <>
      <section id="skills">
        <h2>Skills & Experience</h2>
        <h3>Software Development</h3>
        <ul>
          <li>Problem-solving</li>
          <li>Programming Languages</li>
          <li>Data Structures and Algorithms</li>
          <li>Version Control</li>
        </ul>
        <h3>Communications</h3>
        <ul>
          <li>Listening to understand</li>
          <li>Empathy that builds trust</li>
          <li>Negotiating shared outcomes</li>
          <li>Speaking up with purpose</li>
        </ul>
      </section>
    </>
  );
}
