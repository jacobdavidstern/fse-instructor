// App.jsx
import { useState } from 'react';
import Header from './components/Header';
import AboutSection from './components/AboutSection';
import SkillsSection from './components/SkillsSection';
import ContactSection from './components/ContactSection';
import './App.css';

export default function App() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={darkMode ? 'dark' : 'light'}>
      <button onClick={() => setDarkMode((prev) => !prev)}>
        {darkMode ? 'Light Mode' : 'Dark Mode'}
      </button>

      <Header darkMode={darkMode} />
      <AboutSection darkMode={darkMode} />
      <SkillsSection darkMode={darkMode} />
      <ContactSection darkMode={darkMode} />
    </div>
  );
}
