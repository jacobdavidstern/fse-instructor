// src/components/Leaderboard.jsx

export default function Leaderboard({ scores }) {
  return (
    <div className="leaderboard">
      <h2>Leaderboard</h2>
      <ul>
        {scores.map((s, i) => (
          <li key={i}>
            {s.name}: {s.score}
          </li>
        ))}
      </ul>
    </div>
  );
}
