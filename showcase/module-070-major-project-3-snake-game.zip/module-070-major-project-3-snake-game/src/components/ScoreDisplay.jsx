// src/components/ScoreDisplay.jsx

import { useGameContext } from '../hooks/useGameContext';

export default function ScoreDisplay({ timeLeft }) {
  const { gameState } = useGameContext();
  const { score } = gameState;

  return (
    <div className="score">
      Score: {score} Time left: {timeLeft} s
    </div>
  );
}
