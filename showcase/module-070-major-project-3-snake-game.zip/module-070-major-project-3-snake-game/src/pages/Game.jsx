// src/pages/Game.jsx

import GameBoard from '../components/GameBoard';
import ScoreDisplay from '../components/ScoreDisplay';
import { useGameContext } from '../hooks/useGameContext';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import useTimer from '../hooks/useTimer';

export default function Game() {
  const { gameState } = useGameContext();
  const navigate = useNavigate();

  const { timeLeft, start, stop } = useTimer(180); // 3 minutes

  useEffect(() => {
    start();
    return () => stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (timeLeft === 0) {
      navigate('/gameover', { state: { score: gameState.score } });
    }
  }, [timeLeft, navigate, gameState.score]);

  useEffect(() => {
    if (gameState.isGameOver) {
      navigate('/gameover', { state: { score: gameState.score } });
    }
  }, [gameState.isGameOver, gameState.score, navigate]);

  return (
    <div className="game">
      <ScoreDisplay timeLeft={timeLeft} />
      <GameBoard />
    </div>
  );
}
