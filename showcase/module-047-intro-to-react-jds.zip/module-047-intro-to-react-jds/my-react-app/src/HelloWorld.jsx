// src/HelloWorld.jsx
import './HelloWorld.css';

function HelloWorld({ name }) {
  return <h1 className="hello-world">Hello, {name}!</h1>;
}

export default HelloWorld;
