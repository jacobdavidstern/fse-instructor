// src/App.jsx
import HelloWorld from './HelloWorld';

// Flexbox best for one centered element, Grid for layout patterns.
// Flexbox version
const containerStyle = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  height: '100vh', // not required
  width: '100vw', // required
  backgroundColor: '#f8f8f8',
};

function App() {
  return (
    <div style={containerStyle}>
      <HelloWorld name="Daniel" />
    </div>
  );
}

export default App;

// Grid version
// const containerStyle = {
//   display: 'grid',
//   placeItems: 'center', // shorthand for justify-items + align-items
//   height: '100vh', // not required
//   width: '100vw', // required
//   backgroundColor: '#f8f8f8',
// };
